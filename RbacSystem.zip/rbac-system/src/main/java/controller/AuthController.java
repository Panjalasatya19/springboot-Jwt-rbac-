package controller;
import security.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private JwtUtils jwtUtils;

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password) {
        // Perform authentication (use your service here)
        if ("user".equals(username) && "password".equals(password)) {
            return jwtUtils.generateToken(username); // Return JWT token
        }
        return "Invalid credentials";
    }
    @GetMapping("/secure")
    public String secureEndpoint() {
        return "This is a secure endpoint, you are authenticated!";
    }
}
}
