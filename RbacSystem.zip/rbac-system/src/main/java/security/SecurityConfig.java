package security;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final JwtUtils jwtUtils;
    private MyUserDetails userDetails = new MyUserDetails();

    public SecurityConfig(JwtUtils jwtUtils, MyUserDetails userDetailsService, MyUserDetails userDetails) {
        this.jwtUtils = jwtUtils;
        this.userDetails = userDetails;
    }
 // SecurityFilterChain replaces the need for WebSecurityConfigurerAdapter
    @SuppressWarnings({ "deprecation", "removal" })
	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        // Disable CSRF since we're using JWT and not session-based authentication
        http.csrf().disable()
            .authorizeRequests()
                .requestMatchers("/auth/**", "/register").permitAll()  // Public paths
                .anyRequest().authenticated()  // Protected paths
            .and()
            .addFilterBefore(new JwtAuthenticationFilter(jwtUtils), UsernamePasswordAuthenticationFilter.class);  // Add JWT filter

        return http.build();
    }
 // Configure the AuthenticationManager bean
    @SuppressWarnings("removal")
	@Bean
    public AuthenticationManager authenticationManager(HttpSecurity http) throws Exception {
        return http.getSharedObject(AuthenticationManagerBuilder.class)
                   .userDetailsService(userDetails)
                   .passwordEncoder(passwordEncoder())
                   .and()
                   .build();
    }

    // Define the PasswordEncoder bean for encoding passwords
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
}