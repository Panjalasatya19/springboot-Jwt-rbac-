package security;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class JwtUtils {

    // Secret key for signing the JWT (Keep it safe and secure)
    private static final String SECRET_KEY = "yourSecretKeyHere";
    
    // Expiration time for the token (e.g., 1 hour)
    private static final long EXPIRATION_TIME = 3600000; // 1 hour in milliseconds

    // Generate JWT token
    @SuppressWarnings("deprecation")
	public String generateToken(String username) {
        return Jwts.builder()
                .setSubject(username)  // Set the username as the subject
                .setIssuedAt(new Date())  // Set the issue date
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME))  // Set expiration time
                .signWith(SignatureAlgorithm.HS256, SECRET_KEY)  // Sign the JWT with the secret key
                .compact();
        }
 // Get username from JWT token
    public String getUsernameFromToken(String token) {
        return getClaimsFromToken(token).getSubject();
    }

    // Get expiration date from JWT token
    public Date getExpirationDateFromToken(String token) {
        return getClaimsFromToken(token).getExpiration();
    }

    // Parse claims from JWT token
    @SuppressWarnings("deprecation")
	private Claims getClaimsFromToken(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET_KEY)  // Use the same secret key
                .parseClaimsJws(token)  // Parse the JWT token and get the claims
                .getBody();
    }
 // Check if the token is expired
    public boolean isTokenExpired(String token) {
        return getExpirationDateFromToken(token).before(new Date());
    }

    // Validate JWT token
    public boolean validateToken(String token, String username) {
        return (username.equals(getUsernameFromToken(token)) && !isTokenExpired(token));
    }
}
