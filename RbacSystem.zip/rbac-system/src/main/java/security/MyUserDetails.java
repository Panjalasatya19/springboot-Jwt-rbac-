package security;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails; 
import org.springframework.security.core.userdetails.UserDetailsService; 
import org.springframework.stereotype.Service;
@Service
public class MyUserDetails implements UserDetailsService { 
	@Override 
	public UserDetails loadUserByUsername(String username) { // Here you can fetch user data from your database or a mock repository 
		return User.builder()
				.username(username) 
				.password("password") // Normally, you would fetch the password from the DB 
				.roles("USER") // Assign roles dynamically based on your needs 
				.build(); } 
		
	
}


